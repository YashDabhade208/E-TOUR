package com.example.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "itinerary")
public class Itinerary {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "itinerary_date")
    private String itineraryDate;

    @Column(name = "itinerary_description")
    private String itineraryDescription;

    @ManyToOne
    @JoinColumn(name = "tour_id")
    private Tour tourId;

    // Getters and setters

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getItineraryDate() {
        return itineraryDate;
    }

    public void setItineraryDate(String itineraryDate) {
        this.itineraryDate = itineraryDate;
    }

    public String getItineraryDescription() {
        return itineraryDescription;
    }

    public void setItineraryDescription(String itineraryDescription) {
        this.itineraryDescription = itineraryDescription;
    }

    public Tour getTour() {
        return tourId;
    }

    public void setTour(Tour tour) {
        this.tourId = tour;
    }
}
