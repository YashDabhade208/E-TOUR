package com.example.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Column;

@Entity
@Table(name = "tours")
public class Tour {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "tour_cost")
    private Double tourCost;

    @Column(name = "tour_description")
    private String tourDescription;

    @Column(name = "tour_destination")
    private String tourDestination;

    @Column(name = "tour_duration")
    private Integer tourDuration;

    @Column(name = "tour_name")
    private String tourName;

    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category categoryId;

    // Getters and setters

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Double getTourCost() {
        return tourCost;
    }

    public void setTourCost(Double tourCost) {
        this.tourCost = tourCost;
    }

    public String getTourDescription() {
        return tourDescription;
    }

    public void setTourDescription(String tourDescription) {
        this.tourDescription = tourDescription;
    }

    public String getTourDestination() {
        return tourDestination;
    }

    public void setTourDestination(String tourDestination) {
        this.tourDestination = tourDestination;
    }

    public Integer getTourDuration() {
        return tourDuration;
    }

    public void setTourDuration(Integer tourDuration) {
        this.tourDuration = tourDuration;
    }

    public String getTourName() {
        return tourName;
    }

    public void setTourName(String tourName) {
        this.tourName = tourName;
    }

    public Category getCategory() {
        return categoryId;
    }

    public void setCategory(Category category) {
        this.categoryId = category;
    }
}
