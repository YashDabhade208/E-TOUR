package com.example.model;

import jakarta.persistence.*;

@Entity
public class Passenger 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer passenger_id;
	
	private String name;
	private Integer age;
	private String gender;
	private String mobileNo;
	private String email;
	private String aadhaarNo;
	
	@ManyToOne
    @JoinColumn
	private Booking booking_id;

	public Integer getPassenger_id() {
		return passenger_id;
	}

	public void setPassenger_id(Integer passenger_id) {
		this.passenger_id = passenger_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAadhaarNo() {
		return aadhaarNo;
	}

	public void setAadhaarNo(String aadhaarNo) {
		this.aadhaarNo = aadhaarNo;
	}

	public Booking getBooking_id() {
		return booking_id;
	}

	public void setBooking_id(Booking booking_id) {
		this.booking_id = booking_id;
	}
	
	

	
}
