package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Itinerary;
import com.example.repository.ItineraryRepository;

@Service
public class ItineraryServiceImpl implements ItineraryService {

    @Autowired
    private ItineraryRepository itineraryRepository;

    @Override
    public List<Itinerary> getAllItineraries() {
        return itineraryRepository.findAll();
    }

    @Override
    public Itinerary getItineraryById(Integer id) {
        return itineraryRepository.findById(id).orElseThrow();
    }

    @Override
    public Itinerary createItinerary(Itinerary itinerary) {
        return itineraryRepository.save(itinerary);
    }

    @Override
    public Itinerary updateItinerary(Integer id, Itinerary itinerary) {
        itinerary.setId(id);
        return itineraryRepository.save(itinerary);
    }

    @Override
    public void deleteItinerary(Integer id) {
        itineraryRepository.deleteById(id);
    }
}
