package com.example.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.model.SubCategory;

@Service
public class SubCategoryServiceImpl implements SubCategoryService
{

	@Override
	public List<SubCategory> getAllSubCategories() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SubCategory getSubCategoryById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SubCategory createSubCategory(SubCategory subCategory) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SubCategory updateSubCategory(SubCategory subCategory) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteSubCategory(Integer id) {
		// TODO Auto-generated method stub
		
	}

}
