package com.example.service;

import java.util.List;

import com.example.model.Tour;

public interface TourService {
    List<Tour> getAllTours();
    Tour getTourById(Integer id);
    Tour createTour(Tour tour);
    Tour updateTour(Integer id, Tour tour);
    void deleteTour(Integer id);
}
