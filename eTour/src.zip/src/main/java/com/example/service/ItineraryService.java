package com.example.service;

import java.util.List;

import com.example.model.Itinerary;

public interface ItineraryService {
    List<Itinerary> getAllItineraries();
    Itinerary getItineraryById(Integer id);
    Itinerary createItinerary(Itinerary itinerary);
    Itinerary updateItinerary(Integer id, Itinerary itinerary);
    void deleteItinerary(Integer id);
}
