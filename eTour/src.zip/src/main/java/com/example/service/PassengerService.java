package com.example.service;

import com.example.model.Passenger;
import java.util.List;

public interface PassengerService {
    // Retrieve all passengers
    List<Passenger> getAllPassengers();
    
    // Retrieve a passenger by their ID
    Passenger getPassengerById(Integer id);
    
    // Create a new passenger
    Passenger createPassenger(Passenger passenger);
    
    // Update an existing passenger
    Passenger updatePassenger(Integer id, Passenger passenger);
    
    // Delete a passenger by their ID
    void deletePassenger(Integer id);
}
