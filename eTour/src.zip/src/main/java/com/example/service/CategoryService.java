package com.example.service;

import java.util.List;

import com.example.model.Category;

public interface CategoryService {
    List<Category> getAllCategories();
    Category getCategoryById(Integer id);
    Category createCategory(Category category);
    void deleteCategory(Integer id);
	Category updateCategory(Integer id, Category category);
}
