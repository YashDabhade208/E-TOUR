package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Tour;
import com.example.repository.TourRepository;

@Service
public class TourServiceImpl implements TourService {

    @Autowired
    private TourRepository tourRepository;

    @Override
    public List<Tour> getAllTours() {
        return tourRepository.findAll();
    }

    @Override
    public Tour getTourById(Integer id) {
        return tourRepository.findById(id).orElseThrow();
    }

    @Override
    public Tour createTour(Tour tour) {
        return tourRepository.save(tour);
    }

    @Override
    public Tour updateTour(Integer id, Tour tour) {
        tour.setId(id);
        return tourRepository.save(tour);
    }

    @Override
    public void deleteTour(Integer id) {
        tourRepository.deleteById(id);
    }
}
